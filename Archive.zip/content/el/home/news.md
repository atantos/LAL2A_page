+++
# Experience widget.
widget = "experience"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 50  # Order that this section will appear.

title = "News"
subtitle = "Upcoming Talks, Activities and Calls"

# Date format for experience
#   Refer to https://sourcethemes.com/academic/docs/customization/#date-format
date_format = "Jan 2006"

# Experiences.
#   Add/remove as many `[[experience]]` blocks below as you like.
#   Required fields are `title`, `company`, and `date_start`.
#   Leave `date_end` empty if it's your current employer.
#   Begin/end multi-line descriptions with 3 quotes `"""`.
[[experience]]
  title = "Data Collection"
  company = "Corpus Design and Construction"
  company_url = ""
  location = "Thessaloniki"
  date_start = "2020-01-01"
  date_end = ""
  description = """
  Compiling learners' productions and conducting a pilot study for preparing the annotation scheme of our corpus.
  """

[[experience]]
  title = "Project Start"
  company = "First Meeting"
  company_url = ""
  location = "Thessaloniki"
  date_start = "2019-12-01"
  #date_end = ""
  description = """It's about time we get started! First meeting of our team! Soon more members to join us!"""

+++
