+++
# Contact widget.
widget = "contact"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 60  # Order that this section will appear.

title = "Contact"
subtitle = ""

# Automatically link email and phone?
autolink = true

# Email form provider
#   0: Disable email form
#   1: Netlify (requires that the site is hosted by Netlify)
#   2: formspree.io
email_form = 2
+++

<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d756.9766428247752!2d22.95454031081725!3d40.631942344079235!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb63d9e42547fa353!2zzqDOsc67zrHOuc6sIM6mzrnOu86_z4POv8-GzrnOus6uIM6jz4fOv867zq4gzpEuzqAuzpgu!5e0!3m2!1sel!2sgr!4v1525460145071" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
