+++
# A Skills section created with the Featurette widget.
widget = "featurette"  # See https://sourcethemes.com/academic/docs/page-builder/
headless = true  # This file represents a page section.
active = true  # Activate this widget? true/false
weight = 30  # Order that this section will appear.

title = "ΑΠΗΧΗΣΗ"
subtitle = ""

# Showcase personal skills or business features.
# 
# Add/remove as many `[[feature]]` blocks below as you like.
# 
# For available icons, see: https://sourcethemes.com/academic/docs/widgets/#icons

[[feature]]
  icon = "bullhorn"
  icon_pack = "fas"
  name = "Στην κοινωνία"
  description = "&rarr; Βελτίωση της επικοινωνιακής δεξιότητας των ομιλητών της Ελληνικηής ως Γ2. Η επικοινωνία, κατ’ επέκταση, αντανακλάται στην κοινωνικηή διάδραση από τη στιγμή που επικοινωνιακές και κοινωνικές δεξιότητες είναι άρρηκτα συνδεδεμένες (Newman-Norlund κ.ά., 2009). <br/> <br/>&rarr; Ενίσχυση της αυτοπεποίθησης και του προϊδεασμού του δασκάλου για τις δυσκολίες που προκύπτουν από την πλευρά των μαθητών κατά την εκμάθηση της Γ2, που θα οδηγήσει και στη βελτίωση των διδακτικών τεχνικών, καθώς η όλη διαδικασία θα επεκτείνει την επίγνωση πάνω σε θέματα της διαγλώσσας στη Γ2.<br/> <br/>&rarr; Η προσαρμογή στο ξένο πολιτισμικό τοπίο με τη μορφή ενσωμάτωσης συνδέεται με την αυτοπεποίθηση του μαθητή για τις επιδόσεις του στη διαδρομή της διαγλώσσας. H σύγκλιση μεταξύ των στόχων και των επιτευγμάτων στην εξέλιξη της διαγλώσσας επηρεάζει την προσαρμογή στο ξένο περιβάλλον με ανταποδοτικά οφέλη για τον μαθητή (Jiang κ. ά., 2009)."
  
#[[feature]]
 # icon = ""
 # icon_pack = ""
 # name = ""
 # description = ""  
  
[[feature]]
 icon = "dataverse"
  icon_pack = "ai"
  name = "Στην επιστήμη"
  description = "&rarr; Η Υπολογιστικά Υποβοηθούμενη Ανάλυση Λαθών Computer-aided που θα εφαρμοστεί στο ΛΟΚΓ2 θα will facilitate the emergence of distinct features that can identify certain stages of interlanguage even at the individual’s level. In fact, the researcher as well as the teacher will gain methodologically enriched insight in the path the language learning follows. This, in turn, can be seen as the feedback that the teacher receives with respect to the learning strategies they employ in the classroom. <br/><br/> &rarr; Combination of corpora and experimental methods should also ideally be integrated with linguistic theory. The fact that such an approach can be very rewarding is demonstrated by McKoon & MacFarland (2000: 856), who see as the most compelling aspect of their study the power gained by combining corpus analysis and psycholinguistic experimentation with linguistic theory, demonstrating how theoretical work and empirical work can inform each other. <br/><br/> &rarr; LAL2A is designed to offer provision of remedial influence. Specifically, in the case where the analysis of the individual’s production (written or spoken) may indicate a number of deviating patterns in L2, LAL2A will suggest a set of exercises that will make the learner aware of the target form. <br/><br/> &rarr; A number of advanced experimental techniques (i.e. eye-tracking to track sentence processing) will be used as a means of validating the patterns of interlanguage that emerge from the analysis of naturalistic data (corpora)."

+++
