+++
# Custom widget.
# An example of using the custom widget to create your own homepage section.
# To create more sections, duplicate this file and edit the values below as desired.
widget = "custom"
active = false
date = "2016-04-20T00:00:00"

# Note: a full width section format can be enabled by commenting out the `title` and `subtitle` with a `#`.
title = "Opening Hours"
subtitle = ""

# Order that this section will appear in.
weight = 4

+++

<div class="responsive-iframe-container"><iframe src="https://calendar.google.com/calendar/embed?title=LingLab%20Opening%20Hours&amp;mode=WEEK&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=mu1u7hhmnu6t1mbmeafrs9l29s%40group.calendar.google.com&amp;color=%23A32929&amp;ctz=Europe%2FAthens" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe></div>
