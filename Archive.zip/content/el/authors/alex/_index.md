---
# Display name
name: Αλέξανδρος Τάντος

# Username (this should match the folder name)
authors:
- alex

# Is this the primary user of the site?
superuser: false

# Put priority on the appearance of the members
weight: 1

# Role/position
role: Επιστημονικά Υπεύθυνος

# Telephone number
tel: +30 2310 997134

# Organizations/Affiliations
organizations:
- name: Επίκουρος Καθηγητής Κειμενογλωσσολόγιας και Υπολογιστικής Γλωσσολογίας
  url: ""

# Short bio (displayed in user profile at end of posts)
bio: My research interests include distributed robotics, mobile computing and programmable matter.

interests:
- Υπολογιστική Γλωσσολογίας
- Επεξεργασία Φυσικού Λόγου
- Φορμαλιστική Σημασιολογίας
- Υπερπροτασική Σημασιολογία και Πραγματολογία
- Γλωσσολογία Σωμάτων Κειμένων
- Ανάλυση Γλωσσικών Δεδομένων

education:
  courses:
  - course: Διδακτορικές σπουδές στην Υπολογιστική Σημασιολογία
    institution: Πανεπιστημίο Κωνσταντίας, Γερμανία
    year: 2008
  - course: Μεταπτυχιακές σπουδές (MSc) στην Επεξεργασία Φυσικού Λόγου
    institution: Πανεπιστήμιο του Μάντσεστερ - Ινστιτούτο Επιστήμης και Τεχνολογίας (University of Manchester - Institute of Science and Technology), Ηνωμένο Βασίλειο
    year: 2003
  - course: Πτυχίο στη Γερμανική Γλώσσα και Φιλολογία
    institution: Αριστοτέλειο Πανεπιστήμιο Θεσσαλονίκης
    year: 2000

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: home
  icon_pack: fas
  link: https://www.lit.auth.gr/atantos/en/
- icon: envelope
  icon_pack: fas
  link: 'mailto:alextantos@lit.auth.gr'  # For a direct email link, use "mailto:test@example.org".
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- ""
---

{{% aligned_text %}}

Ο Αλέξανδρος Τάντος έχει απασχοληθεί σε σειρά έργων υπολογιστικής γλωσσολογίας και επεξεργασίας φυσικού λόγου. Τα τελευταία χρόνια, η έμφαση στην έρευνά του είναι η εφαρμογή αλγορίθμων μηχανικής μάθησης σε γλωσσικά δεδομένα με στόχο την καλύτερη κατανόηση της κατάκτησης/εκμάθησης της δεύτερης γλώσσας.

{{% /aligned_text %}}
